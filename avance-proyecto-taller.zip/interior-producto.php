<?php require 'header.php'; ?>
    
    <section id="detalle-producto">
        <div class="detalle-producto-content">
            <div class="imagen">
                <img src="assets/img/productos/producto1.png" alt="Detalle Producto">
            </div>
            <div class="texto">
                <h2>Nombre del Producto</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus lacinia odio vitae vestibulum vestibulum.</p>
                <p class="precio">$99.99</p>
                <button>Comprar</button>
            </div>
        </div>
    </section>
<?php require 'footer.php'; ?>
