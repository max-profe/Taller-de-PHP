// Aquí puedes añadir cualquier funcionalidad adicional de JavaScript si es necesario
document.addEventListener("DOMContentLoaded", function() {
    // Ejemplo de funcionalidad JavaScript
    console.log("Proyecto OnePage cargado correctamente.");
});
