<?php
    //ini_set('display_errors', 1);
?>
<?php require 'header.php'; ?>
<main>
<section id="inicio">
        <div class="inicio-content">
            <h1>Bienvenidos a nuestro proyecto</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus lacinia odio vitae vestibulum vestibulum.</p>
        </div>
    </section>

    <section id="quienes-somos">
        <div class="quienes-somos-content">
            <div class="texto">
                <h2>Quiénes Somos</h2>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dignissimos amet harum sit laudantium. Expedita itaque laboriosam perferendis accusantium exercitationem sed. Facilis est iusto quam deserunt perferendis fugiat totam dolorum debitis?</p>
            </div>
            <div class="imagen">
                <img src="assets/img/quienes-somos.jpg" alt="Quiénes Somos">
            </div>
        </div>
    </section>

    <section id="productos">
        <h2>Nuestros Productos</h2>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus lacinia odio vitae vestibulum vestibulum.</p>
        <div class="productos-gallery">
            <div class="producto">
                <img src="assets/img/productos/producto1.png" alt="Producto 1">
                <h3>Producto 1</h3>
                <p>Lorem ipsum dolor sit amet.</p>
                <a href="interior-producto.php">Ver producto</a>
            </div>
            <div class="producto">
                <img src="assets/img/productos/producto2.png" alt="Producto 2">
                <h3>Producto 2</h3>
                <p>Lorem ipsum dolor sit amet.</p>
                <a href="interior-producto.php">Ver producto</a>
            </div>
            <div class="producto">
                <img src="assets/img/productos/producto3.png" alt="Producto 3">
                <h3>Producto 3</h3>
                <p>Lorem ipsum dolor sit amet.</p>
                <a href="interior-producto.php">Ver producto</a>
            </div>
            <div class="producto">
                <img src="assets/img/productos/producto1.png" alt="Producto 4">
                <h3>Producto 4</h3>
                <p>Lorem ipsum dolor sit amet.</p>
                <a href="interior-producto.php">Ver producto</a>
            </div>
            <div class="producto">
                <img src="assets/img/productos/producto3.png" alt="Producto 5">
                <h3>Producto 5</h3>
                <p>Lorem ipsum dolor sit amet.</p>
                <a href="interior-producto.php">Ver producto</a>
            </div>
        </div>
    </section>

    <section id="contacto">
        <div class="contenedor">
            <h2>Contacto</h2>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
            <form>
                <label for="name">Nombre:</label>
                <input type="text" id="name" name="name" required>
                <label for="email">Correo:</label>
                <input type="email" id="email" name="email" required>
                <label for="message">Mensaje:</label>
                <textarea id="message" name="message" required></textarea>
                <button type="submit">Enviar</button>
            </form>
        </div>
    </section>
</main>
<?php require 'footer.php'; ?>