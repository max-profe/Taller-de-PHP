<?php 
//variables de conexión
$servidor = "localhost";
$usuario = "pofe_max";
$pass = "Pmv4n7kzVvfrb.Q9";
$nombre_bd = "pofe_max"; 

//conexión a mysql
$conexion = new mysqli($servidor, $usuario, $pass, $nombre_bd);

if($conexion->connect_error){
    die("Error de conexión: " . $conexion->connect_error);
}else{
    echo 'Conexión exitosa.';
}

?>