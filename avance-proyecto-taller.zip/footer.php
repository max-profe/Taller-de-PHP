
<footer>
        <p>Derechos reservados &copy; 2024</p>
        <div class="social-icons">
            <a href="#"><img src="assets/img/redes/instagram.svg" alt="Icono red social Instagram"></a>
            <a href="#"><img src="assets/img/redes/twitch.svg" alt="Icono red social Twitch"></a>
            <a href="#"><img src="assets/img/redes/discord.svg" alt="Icono red social Discord"></a>
        </div>
    </footer>

    <script src="assets/js/scripts.js"></script>
</body>
</html>
