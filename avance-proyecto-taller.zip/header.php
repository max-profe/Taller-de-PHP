<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proyecto OnePage</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/index.css">
</head>
<body>
    <header>
        <div class="logo"><a href="#inicio">MiLogo</a></div>
        <nav>
            <ul>
                <li><a href="index.php#inicio">Inicio</a></li>
                <li><a href="index.php#quienes-somos">Quiénes Somos</a></li>
                <li><a href="index.php#productos">Productos</a></li>
                <li><a href="index.php#contacto">Contacto</a></li>
            </ul>
        </nav>
    </header>
    